from flask import Flask, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import String, Float
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

class Base(DeclarativeBase):
    pass

app = Flask(__name__)

app.config['SECRET_KEY'] = 'dev-chi-dung-khi-phat-trien'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sv.db'

db = SQLAlchemy(model_class=Base)
db.init_app(app)

class Student(db.Model):
    __tablename__ = 'student'

    id: Mapped[int] = mapped_column(primary_key=True)
    mssv: Mapped[str] = mapped_column(String(10), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    gpa: Mapped[float] = mapped_column(Float, default=0.0)

    def __repr__(self):
        return f'<Student {self.mssv} {self.name}>'

with app.app_context():
    db.create_all()

    if db.session.scalar(db.select(db.func.count(Student.id))) == 0:
        sv1 = Student(mssv="1012200001", name="Nguyễn Văn An", gpa=8.12)
        
        danh_sach_sv = [
            Student(mssv="1012200002", name="Trần Thị Bích", gpa=9.1),
            Student(mssv="1012200003", name="Lê Hoàng Tùng", gpa=7.5),
            Student(mssv="1012200004", name="Phạm Minh Dũng", gpa=6.8),
            Student(mssv="1012200005", name="Đặng Thu Hà", gpa=8.5)
        ]
        
        db.session.add(sv1)
        db.session.add_all(danh_sach_sv)
        db.session.commit()

@app.route('/')
def index():
    students = db.session.scalars(db.select(Student)).all()
    return render_template('students.html', students=students)

if __name__ == '__main__':
    app.run(debug=True)